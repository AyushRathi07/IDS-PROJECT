# Decision-Tree-Classifier-Numerical-String-Dataset-
Decision tree classifier build as a part of IDS Project
